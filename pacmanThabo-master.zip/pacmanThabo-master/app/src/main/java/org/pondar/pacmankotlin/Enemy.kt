package org.pondar.pacmankotlin

class Enemy (var x: Int, var y: Int, var alive: Boolean = true){
}