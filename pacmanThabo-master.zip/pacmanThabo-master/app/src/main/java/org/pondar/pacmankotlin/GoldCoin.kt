package org.pondar.pacmankotlin

//Here you need to fill out what should be in a GoldCoin and what should the constructor be
class  GoldCoin(
        var coinX : Int,
        var coinY : Int,
        var taken : Boolean = false
) {}
